import UIKit
import CoreData

class SecondVC: UIViewController , UITableViewDataSource , UITableViewDelegate {
    
    var SecondArr = [Movie]()
    @IBOutlet weak var SecondTableView: UITableView!
   
    override func viewDidLoad() {
        super.viewDidLoad()
        loadMovies()
    }
    
    func loadMovies (){
        let fetchRequest : NSFetchRequest<Movie> = Movie.fetchRequest()
        do{
            SecondArr = try context.fetch(fetchRequest)
        }
        catch{
            print("error")
        }
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return SecondArr.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell") as! SecondTableViewCell
        cell.setMovie(movie: SecondArr[indexPath.row])
        return cell
    }
  
    @IBAction func BackBu(_ sender: UIBarButtonItem) {
        dismiss(animated: true, completion: nil)
    }
}
