import UIKit

class FirstCell {
    
    var title:String
    var image:String
    
    init(title:String,image:String) {
        self.image=image
        self.title=title
    }
    
    
}
