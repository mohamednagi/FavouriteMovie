import UIKit

class SecondCell {
 
    var title2:String
    var image2:String
    
    
    init(title2:String,image2:String) {
        self.image2=image2
        self.title2=title2
    }
    
    
    
}
